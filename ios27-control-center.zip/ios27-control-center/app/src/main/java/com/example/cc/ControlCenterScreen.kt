package com.example.cc

import android.content.Context
import android.content.Intent
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.provider.Settings
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.foundation.Canvas
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.platform.LocalConfiguration

private val Tile = RoundedCornerShape(40.dp)
private val Round = RoundedCornerShape(50)

@Composable
fun ControlCenterScreen() {
    val ctx = LocalContext.current
    val audio = remember { ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager }
    val camera = remember { ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager }

    var torchOn by remember { mutableStateOf(false) }
    var focusOn by remember { mutableStateOf(false) }
    var volume by remember {
        mutableFloatStateOf(
            audio.getStreamVolume(AudioManager.STREAM_MUSIC).toFloat() /
                audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        )
    }
    var brightness by remember { mutableFloatStateOf(0.6f) }
    var lowPower by remember { mutableStateOf(false) }
    var rotationLocked by remember { mutableStateOf(false) }

    val isDark = androidx.compose.foundation.isSystemInDarkTheme()
    val bg = if (isDark) Color.Black else Color(0xFFEDEDF2)
    val glassOff = if (isDark) Color(0x33FFFFFF) else Color(0x33000000)
    val on = if (isDark) Color.White else Color.Black
    val onText = if (isDark) Color.Black else Color.White

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(bg)
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp, vertical = 48.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Top bar
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            CircleIcon(Icons.Default.Add, glassOff, on) { }
            CircleIcon(Icons.Default.PowerSettingsNew, glassOff, on) {
                ctx.startActivity(Intent(Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            }
        }

        // Connectivity block
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                PillTile(
                    title = "Airplane Mode", subtitle = "Off",
                    icon = Icons.Default.AirplanemodeActive, active = false,
                    activeColor = Color(0xFFFF9500), inactive = glassOff, onActive = on,
                    height = 84.dp, onClick = { openSettings(ctx, Settings.ACTION_AIRPLANE_MODE_SETTINGS) }
                )
                PillTile(
                    title = "Bluetooth", subtitle = "Settings",
                    icon = Icons.Default.Bluetooth, active = false,
                    activeColor = Color(0xFF0A84FF), inactive = glassOff, onActive = on,
                    height = 84.dp, onClick = { openSettings(ctx, Settings.ACTION_BLUETOOTH_SETTINGS) }
                )
                PillTile(
                    title = "Low Power", subtitle = if (lowPower) "On" else "Off",
                    icon = Icons.Default.BatteryChargingFull, active = lowPower,
                    activeColor = Color(0xFFFFD60A), inactive = glassOff, onActive = Color.Black,
                    height = 84.dp, onClick = { lowPower = !lowPower }
                )
                PillTile(
                    title = "Orientation", subtitle = if (rotationLocked) "Locked" else "Unlocked",
                    icon = Icons.Default.ScreenLockRotation, active = rotationLocked,
                    activeColor = Color(0xFFFF6482), inactive = glassOff, onActive = Color.Black,
                    height = 84.dp, onClick = { rotationLocked = !rotationLocked }
                )
            }
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                PillTile(
                    title = "Wi-Fi", subtitle = "Settings",
                    icon = Icons.Default.Wifi, active = true,
                    activeColor = Color(0xFF0A84FF), inactive = glassOff, onActive = onText,
                    height = 84.dp, onClick = { openSettings(ctx, Settings.Panel.ACTION_WIFI) }
                )
                PillTile(
                    title = "Cellular Data", subtitle = "On",
                    icon = Icons.Default.SignalCellularAlt, active = true,
                    activeColor = Color(0xFF30D158), inactive = glassOff, onActive = onText,
                    height = 84.dp, onClick = { openSettings(ctx, Settings.Panel.ACTION_INTERNET_CONNECTIVITY) }
                )
                // Sliders
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.height(168.dp)) {
                    VerticalSlider(
                        value = brightness, onChange = { brightness = it },
                        icon = Icons.Default.LightMode, track = glassOff, fill = on, iconOn = onText,
                        modifier = Modifier.weight(1f)
                    )
                    VerticalSlider(
                        value = volume,
                        onChange = {
                            volume = it
                            audio.setStreamVolume(
                                AudioManager.STREAM_MUSIC,
                                (it * audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC)).toInt(),
                                0
                            )
                        },
                        icon = Icons.AutoMirrored.Filled.VolumeUp, track = glassOff, fill = on, iconOn = onText,
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }

        // Icon row
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            PillTile(
                title = "Focus", subtitle = if (focusOn) "On" else null,
                icon = Icons.Default.Person, active = focusOn,
                activeColor = Color(0xFF5E5CE6), inactive = glassOff, onActive = Color.White,
                height = 84.dp, onClick = { focusOn = !focusOn }, modifier = Modifier.weight(1f)
            )
            CircleIcon(Icons.Default.Radio, glassOff, on, size = 84.dp) { }
            CircleIcon(Icons.Default.FiberManualRecord, Color(0xFFFF3B30), Color.White, size = 84.dp) { }
        }

        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            CircleIcon(Icons.Default.FlashlightOn, if (torchOn) Color.White else glassOff,
                if (torchOn) Color.Black else on, size = 84.dp) {
                torchOn = !torchOn
                runCatching {
                    camera.setTorchMode(camera.cameraIdList.first(), torchOn)
                }
            }
            CircleIcon(Icons.Default.Timer, glassOff, on, size = 84.dp) {
                openSettings(ctx, Settings.ACTION_DATE_SETTINGS)
            }
            CircleIcon(Icons.Default.MusicNote, glassOff, on, size = 84.dp) { }
            CircleIcon(Icons.Default.Face, glassOff, on, size = 84.dp) { }
        }

        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            CircleIcon(Icons.Default.Notifications, glassOff, on, size = 84.dp) { }
            CircleIcon(Icons.Default.DirectionsCar, glassOff, on, size = 84.dp) { }
            CircleIcon(Icons.Default.Language, glassOff, on, size = 84.dp) { }
            CircleIcon(Icons.Default.Calculate, glassOff, on, size = 84.dp) { }
        }

        // Media tile
        Surface(
            shape = Tile,
            color = glassOff,
            modifier = Modifier.fillMaxWidth().height(140.dp)
        ) {
            Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(100.dp).clip(RoundedCornerShape(24.dp)).background(Color(0x22808080)))
                Spacer(Modifier.width(16.dp))
                Column(Modifier.weight(1f)) {
                    Text("Not Playing", color = on, fontWeight = FontWeight.SemiBold, fontSize = 18.sp)
                    Spacer(Modifier.height(12.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                        Icon(Icons.Default.FastRewind, null, tint = on)
                        Icon(Icons.Default.PlayArrow, null, tint = on)
                        Icon(Icons.Default.FastForward, null, tint = on)
                    }
                }
            }
        }
    }
}

private fun openSettings(ctx: Context, action: String) {
    ctx.startActivity(Intent(action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
}

@Composable
private fun CircleIcon(
    icon: ImageVector,
    bg: Color,
    tint: Color,
    size: androidx.compose.ui.unit.Dp = 44.dp,
    onClick: () -> Unit
) {
    Box(
        Modifier.size(size).clip(Round).background(bg).clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Icon(icon, null, tint = tint)
    }
}

@Composable
private fun PillTile(
    title: String,
    subtitle: String?,
    icon: ImageVector,
    active: Boolean,
    activeColor: Color,
    inactive: Color,
    onActive: Color,
    height: androidx.compose.ui.unit.Dp,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    val bg = if (active) activeColor else inactive
    val fg = if (active) onActive else Color.Unspecified
    Row(
        modifier
            .fillMaxWidth()
            .height(height)
            .clip(Round)
            .background(bg)
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, null, tint = if (active) onActive else MaterialTheme.colorScheme.onSurface)
        Spacer(Modifier.width(12.dp))
        Column {
            Text(title, fontWeight = FontWeight.SemiBold, fontSize = 15.sp,
                color = if (active) fg else MaterialTheme.colorScheme.onSurface)
            if (subtitle != null) {
                Text(subtitle, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}

@Composable
private fun VerticalSlider(
    value: Float,
    onChange: (Float) -> Unit,
    icon: ImageVector,
    track: Color,
    fill: Color,
    iconOn: Color,
    modifier: Modifier = Modifier
) {
    Box(
        modifier
            .fillMaxHeight()
            .clip(Tile)
            .background(track)
            .pointerInputVertical { onChange(it) },
        contentAlignment = Alignment.BottomCenter
    ) {
        Canvas(Modifier.fillMaxSize()) {
            drawRect(
                color = fill,
                topLeft = Offset(0f, size.height * (1f - value)),
                size = Size(size.width, size.height * value)
            )
        }
        Icon(icon, null, tint = iconOn, modifier = Modifier.padding(bottom = 16.dp))
    }
}

private fun Modifier.pointerInputVertical(onValue: (Float) -> Unit): Modifier =
    this.pointerInput(Unit) {
        val h = size.height.toFloat()
        detectVerticalDragGestures(
            onDragStart = { offset -> onValue((1f - offset.y / h).coerceIn(0f, 1f)) },
            onVerticalDrag = { change, _ ->
                onValue((1f - change.position.y / h).coerceIn(0f, 1f))
            }
        )
    }

# Magisk module

1. Скопируйте `app-debug.apk` из артефакта GitHub Actions в
   `magisk/system/priv-app/ControlCenter/ControlCenter.apk`.
2. Упакуйте папку `magisk` в zip (содержимое, а не сама папка).
3. Установите zip через Magisk, перезагрузите устройство.

Модуль не заменяет системную шторку, а только добавляет приложение с системными правами.

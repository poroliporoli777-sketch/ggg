#!/system/bin/sh
# Magisk installer: put the APK under /system/priv-app and grant privileged permissions.
SKIPUNZIP=0
ui_print "- Installing Control Center as system app"
if [ ! -f "$MODPATH/system/priv-app/ControlCenter/ControlCenter.apk" ]; then
  abort "APK missing: place app-debug.apk as system/priv-app/ControlCenter/ControlCenter.apk"
fi
set_perm_recursive "$MODPATH/system" 0 0 0755 0644

package com.example.darkkeyboard

import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.inputmethodservice.InputMethodService
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.text.InputType
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.LinearLayout
import android.widget.TextView

class DarkKeyboardService : InputMethodService() {

    private enum class Mode { LETTERS, SYMBOLS1, SYMBOLS2 }
    private enum class Shift { OFF, ON, CAPS }

    private companion object {
        val BG = Color.argb(150, 16, 16, 20)
        val GLASS_EDGE = Color.argb(46, 255, 255, 255)
        val KEY = Color.argb(48, 255, 255, 255)
        val KEY_PRESSED = Color.argb(150, 0, 0, 0)
        val KEY_DARK = Color.argb(26, 255, 255, 255)
        val KEY_ACTIVE = Color.argb(225, 255, 255, 255)
        const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT

        val LAYOUTS = listOf(
            listOf("qwertyuiop", "asdfghjkl", "zxcvbnm"),
            listOf("йцукенгшщзхъ", "фывапролджэ", "ячсмитьбю"),
            listOf("йүукенңгшзх", "өывапролджэ", "ячсмитьбю")
        )
        val LANG_NAMES = listOf("EN", "RU", "Ты")
        val DEFAULT_SUG = listOf(
            listOf("I", "the", "I'm"),
            listOf("Я", "не", "что"),
            listOf("", "", "")
        )
        val SYM1 = listOf("1234567890", "-/:;()€&@\"", ".,?!'")
        val SYM2 = listOf("[]{}#%^*+=", "_\\|~<>£¥•\$", ".,?!'")
    }

    private val ui = Handler(Looper.getMainLooper())
    private var mode = Mode.LETTERS
    private var shift = Shift.OFF
    private var lang = 0
    private var lastShiftTap = 0L
    private val currentWord = StringBuilder()

    private lateinit var keysBox: LinearLayout
    private lateinit var sug: Array<TextView>
    private val letterKeys = mutableListOf<TextView>()
    private var shiftKey: TextView? = null

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun rounded(color: Int, r: Int = 11) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(r).toFloat()
        setStroke(dp(1), GLASS_EDGE)
    }

    // ---------------------------------------------------------------- lifecycle

    override fun onEvaluateFullscreenMode() = false

    override fun onCreateInputView(): View {
        val r = dp(24).toFloat()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = GradientDrawable().apply {
                setColor(BG)
                cornerRadii = floatArrayOf(r, r, r, r, 0f, 0f, 0f, 0f)
                setStroke(dp(1), GLASS_EDGE)
            }
            setPadding(dp(4), dp(4), dp(4), dp(8))
        }
        window?.window?.let { w ->
            w.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                try {
                    w.setBackgroundBlurRadius(70)
                } catch (_: Throwable) {
                }
            }
        }
        root.addView(buildSuggestionBar())
        keysBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(keysBox)
        render()
        updateSuggestions()
        return root
    }

    override fun onStartInputView(info: EditorInfo?, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        currentWord.clear()
        val cls = (info?.inputType ?: 0) and InputType.TYPE_MASK_CLASS
        mode = if (cls == InputType.TYPE_CLASS_NUMBER || cls == InputType.TYPE_CLASS_PHONE)
            Mode.SYMBOLS1 else Mode.LETTERS
        shift = Shift.OFF
        if (::keysBox.isInitialized) {
            render()
            autoCaps()
            updateSuggestions()
        }
    }

    // ---------------------------------------------------------------- suggestions bar

    private fun buildSuggestionBar(): LinearLayout {
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(MATCH, dp(44))
        }
        sug = Array(3) {
            TextView(this).apply {
                gravity = Gravity.CENTER
                textSize = 17f
                setTextColor(Color.parseColor("#D0D0D0"))
                layoutParams = LinearLayout.LayoutParams(0, MATCH, 1f)
                setOnClickListener { onSuggestion(text.toString()) }
            }
        }
        sug.forEachIndexed { i, tv ->
            if (i > 0) {
                bar.addView(View(this).apply {
                    setBackgroundColor(Color.argb(60, 255, 255, 255))
                    layoutParams = LinearLayout.LayoutParams(dp(1), dp(20)).apply {
                        gravity = Gravity.CENTER_VERTICAL
                    }
                })
            }
            bar.addView(tv)
        }
        return bar
    }

    private fun updateSuggestions() {
        if (!::sug.isInitialized) return
        val w = currentWord.toString()
        val items = if (w.isEmpty()) DEFAULT_SUG[lang] else listOf("", w, "")
        for (i in 0..2) sug[i].text = items[i]
    }

    private fun onSuggestion(s: String) {
        if (s.isEmpty()) return
        val ic = currentInputConnection ?: return
        if (currentWord.isNotEmpty()) ic.deleteSurroundingText(currentWord.length, 0)
        ic.commitText("$s ", 1)
        currentWord.clear()
        updateSuggestions()
        autoCaps()
    }

    // ---------------------------------------------------------------- rendering

    private fun row(heightDp: Int = 54) = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        layoutParams = LinearLayout.LayoutParams(MATCH, dp(heightDp))
    }

    private fun spacer(w: Float) = View(this).apply {
        layoutParams = LinearLayout.LayoutParams(0, 1, w)
    }

    private fun render() {
        keysBox.removeAllViews()
        letterKeys.clear()
        shiftKey = null
        renderKeys()
        applyShift()
    }

    private fun renderKeys() {
        val rows = when (mode) {
            Mode.LETTERS -> LAYOUTS[lang]
            Mode.SYMBOLS1 -> SYM1
            else -> SYM2
        }
        val r1 = rows[0]
        val r2 = rows[1]
        val r3 = rows[2]

        keysBox.addView(row().also { r -> r1.forEach { r.addView(charKey(it, 1f)) } })

        keysBox.addView(row().also { r ->
            val sp = (r1.length - r2.length) / 2f
            if (sp > 0) r.addView(spacer(sp))
            r2.forEach { r.addView(charKey(it, 1f)) }
            if (sp > 0) r.addView(spacer(sp))
        })

        keysBox.addView(row().also { r ->
            val edge = if (mode == Mode.LETTERS) (r1.length - r3.length) / 2f else 1.5f
            when (mode) {
                Mode.LETTERS -> {
                    val sk = key("⇧", edge, special = true, normalColor = {
                        if (shift == Shift.OFF) KEY_DARK else KEY_ACTIVE
                    }) { onShiftTap() }
                    shiftKey = sk
                    r.addView(sk)
                    r3.forEach { r.addView(charKey(it, 1f)) }
                }
                Mode.SYMBOLS1 -> {
                    r.addView(key("#+=", edge, special = true, sp = 16f) { mode = Mode.SYMBOLS2; render() })
                    r3.forEach { r.addView(charKey(it, 1.4f)) }
                }
                else -> {
                    r.addView(key("123", edge, special = true, sp = 16f) { mode = Mode.SYMBOLS1; render() })
                    r3.forEach { r.addView(charKey(it, 1.4f)) }
                }
            }
            r.addView(key("⌫", edge, special = true, autoRepeat = true) { onBackspace() })
        })

        keysBox.addView(row().also { r ->
            val letters = mode == Mode.LETTERS
            r.addView(key(if (letters) "123" else "ABC", 2.3f, special = true, sp = 16f) {
                mode = if (letters) Mode.SYMBOLS1 else Mode.LETTERS
                render()
                if (!letters) autoCaps()
            })
            r.addView(key(if (letters) LANG_NAMES[lang] else "", 5f, sp = 14f,
                onLong = { switchLang() }) { onSpace() })
            val act = imeAction()
            val enterLabel = when (act) {
                EditorInfo.IME_ACTION_NONE -> "↵"
                EditorInfo.IME_ACTION_SEARCH -> "🔍"
                EditorInfo.IME_ACTION_SEND -> "➤"
                EditorInfo.IME_ACTION_DONE -> "✓"
                else -> "→"
            }
            r.addView(key(enterLabel, 2.3f, special = true) { onEnter() })
        })

        keysBox.addView(row(44).also { r ->
            r.addView(icon("🌐", onLong = {
                (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).showInputMethodPicker()
            }) { switchLang() })
            r.addView(spacer(1f))
            r.addView(icon("🎤") {
                (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).showInputMethodPicker()
            })
        })
    }

    private fun charKey(c: Char, weight: Float): TextView {
        val tv = key(c.toString(), weight) { onChar(c) }
        if (mode == Mode.LETTERS) {
            tv.tag = c
            letterKeys.add(tv)
        }
        return tv
    }

    private fun icon(label: String, onLong: (() -> Unit)? = null, onClick: () -> Unit) = TextView(this).apply {
        text = label
        textSize = 20f
        setTextColor(Color.parseColor("#E0E0E0"))
        gravity = Gravity.CENTER
        layoutParams = LinearLayout.LayoutParams(dp(64), MATCH)
        setOnClickListener { onClick() }
        if (onLong != null) setOnLongClickListener { onLong(); true }
    }

    private fun key(
        label: String,
        weight: Float,
        special: Boolean = false,
        sp: Float = 22f,
        autoRepeat: Boolean = false,
        onLong: (() -> Unit)? = null,
        normalColor: () -> Int = { if (special) KEY_DARK else KEY },
        onTap: () -> Unit
    ): TextView {
        val tv = TextView(this)
        tv.text = label
        tv.textSize = sp
        tv.setTextColor(Color.WHITE)
        tv.gravity = Gravity.CENTER
        tv.background = rounded(normalColor())
        tv.layoutParams = LinearLayout.LayoutParams(0, MATCH, weight).apply {
            setMargins(dp(3), dp(4), dp(3), dp(4))
        }
        val pressedColor = KEY_PRESSED
        var longFired = false
        val longRun = Runnable {
            longFired = true
            tv.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
            onLong?.invoke()
        }
        val repeatRun = object : Runnable {
            override fun run() {
                onTap()
                ui.postDelayed(this, 50)
            }
        }
        tv.setOnTouchListener { v, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    tv.background = rounded(pressedColor)
                    v.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
                    longFired = false
                    if (autoRepeat) {
                        onTap()
                        ui.postDelayed(repeatRun, 400)
                    } else if (onLong != null) {
                        ui.postDelayed(longRun, 400)
                    }
                }
                MotionEvent.ACTION_UP -> {
                    ui.removeCallbacks(repeatRun)
                    ui.removeCallbacks(longRun)
                    tv.background = rounded(normalColor())
                    if (!autoRepeat && !longFired) onTap()
                }
                MotionEvent.ACTION_CANCEL -> {
                    ui.removeCallbacks(repeatRun)
                    ui.removeCallbacks(longRun)
                    tv.background = rounded(normalColor())
                }
            }
            true
        }
        return tv
    }

    // ---------------------------------------------------------------- shift

    private fun onShiftTap() {
        val now = SystemClock.uptimeMillis()
        shift = when {
            shift == Shift.CAPS -> Shift.OFF
            shift == Shift.ON && now - lastShiftTap < 400 -> Shift.CAPS
            shift == Shift.ON -> Shift.OFF
            else -> Shift.ON
        }
        lastShiftTap = now
        applyShift()
    }

    private fun setShift(s: Shift) {
        shift = s
        applyShift()
    }

    private fun applyShift() {
        for (tv in letterKeys) {
            val c = tv.tag as Char
            tv.text = if (shift == Shift.OFF) c.toString() else c.toString().uppercase()
        }
        shiftKey?.let {
            it.text = if (shift == Shift.CAPS) "⇪" else "⇧"
            it.setTextColor(if (shift == Shift.OFF) Color.WHITE else Color.BLACK)
            it.background = rounded(if (shift == Shift.OFF) KEY_DARK else KEY_ACTIVE)
        }
    }

    private fun autoCaps() {
        if (shift == Shift.CAPS || mode != Mode.LETTERS) return
        val ic = currentInputConnection ?: return
        val ei = currentInputEditorInfo
        val caps = if (ei != null && ei.inputType != InputType.TYPE_NULL)
            ic.getCursorCapsMode(ei.inputType) else 0
        setShift(if (caps != 0) Shift.ON else Shift.OFF)
    }

    // ---------------------------------------------------------------- input actions

    private fun commit(s: String) {
        currentInputConnection?.commitText(s, 1)
    }

    private fun onChar(c: Char) {
        val upper = mode == Mode.LETTERS && shift != Shift.OFF
        val out = if (upper) c.toString().uppercase() else c.toString()
        commit(out)
        if (c.isLetter() || (c == '\'' && currentWord.isNotEmpty())) currentWord.append(out)
        else currentWord.clear()
        if (mode == Mode.LETTERS && shift == Shift.ON) setShift(Shift.OFF)
        updateSuggestions()
    }

    private fun onSpace() {
        commit(" ")
        currentWord.clear()
        updateSuggestions()
        autoCaps()
    }

    private fun onBackspace() {
        sendDownUpKeyEvents(KeyEvent.KEYCODE_DEL)
        if (currentWord.isNotEmpty()) currentWord.setLength(currentWord.length - 1)
        updateSuggestions()
        autoCaps()
    }

    private fun imeAction(): Int {
        val ei = currentInputEditorInfo ?: return EditorInfo.IME_ACTION_NONE
        if ((ei.imeOptions and EditorInfo.IME_FLAG_NO_ENTER_ACTION) != 0) return EditorInfo.IME_ACTION_NONE
        val a = ei.imeOptions and EditorInfo.IME_MASK_ACTION
        return if (a == EditorInfo.IME_ACTION_UNSPECIFIED) EditorInfo.IME_ACTION_NONE else a
    }

    private fun onEnter() {
        val ic = currentInputConnection ?: return
        val act = imeAction()
        if (act != EditorInfo.IME_ACTION_NONE) ic.performEditorAction(act)
        else sendDownUpKeyEvents(KeyEvent.KEYCODE_ENTER)
        currentWord.clear()
        updateSuggestions()
        autoCaps()
    }

    private fun switchLang() {
        lang = (lang + 1) % LAYOUTS.size
        currentWord.clear()
        render()
        updateSuggestions()
        autoCaps()
    }
}
